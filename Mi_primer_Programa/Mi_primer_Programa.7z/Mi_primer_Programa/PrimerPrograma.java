
public class PrimerPrograma {
    public static void main(String[] args){
        //Imprime multiples Strings con mi nombre, edad y ciudad natal
        System.out.println("Mi nombre es Santiago");
        System.out.println("Tengo 21 años de edad");
        System.out.println("Mi ciudad natal es Entre Rios, ARG"); 
    }

}
