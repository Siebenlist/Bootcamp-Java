public class objectTest{
    public static void main(String[] args){
        Human h = new Human(3, 3, 3, 100);
        h.attack(h);
    }
}