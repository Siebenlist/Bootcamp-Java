public class Main {
    public static void main(String[] args) {
        Calculadora calc = new Calculadora();
        calc.performOperation(10, "+", 10);
    }
}