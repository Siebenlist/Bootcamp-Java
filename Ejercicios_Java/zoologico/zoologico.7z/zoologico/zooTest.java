public class zooTest{
    public static void main(String[] args){
        Gorilla g = new Gorilla();
        Murcielago m = new Murcielago();
        // g.throwSomething();
        // g.throwSomething();
        // g.throwSomething();
        // g.eatBananas();
        // g.eatBananas();
        // g.climb();

        m.fly();
        m.fly();
        m.eatHumans();
        m.eatHumans();
        m.attackTown();
        m.attackTown();
        m.attackTown();
    }
}