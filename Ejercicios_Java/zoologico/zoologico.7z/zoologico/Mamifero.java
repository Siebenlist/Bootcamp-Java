public class Mamifero {
         protected int energy;

         public Mamifero(int energy) {
            this.energy = energy;
        }

        public Integer displayEnergy(){
            return energy;
    }
}
