public class FizzBuzz {
    public static void main(String[] args) {
        FizzBuzzLogic iD = new FizzBuzzLogic();
        String result = iD.fizzBuzz(15);
        System.out.println(result);
    }
}